// let handler = async (m, { conn, command, text }) => {
//   conn.reply(m.chat, `
// *Pertanyaan:* ${m.text}
// *Jawaban:* ${conn.pickRandom(['Yayayaya', 'Mungkin iya', 'Bisa jadi', 'G', 'Tidak', 'Y', 'Woiya jelas!', 'jelas iya!! gak bisa ditawar lagi', 'ngga mungkin', 'Ngga mungkin dan gak akan pernah', 'iya, kenapa? ga terima? sini bergelud!', 'ngga titik.'])}
// `.trim(), m, m.mentionedJid ? {
//     contextInfo: {
//       mentionedJid: m.mentionedJid
//     }
//   } : {})
// }
// handler.help = ['apakah <pertanyaan?> ']
// handler.tags = ['kerang']
// handler.customPrefix = /^(..?)?apakah$/i
// handler.disabled = true

// module.exports = handler


